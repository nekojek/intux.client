package WizClient.event.impl;

import WizClient.event.Event;

public class ClientTickEvent extends Event{

	
	
}
