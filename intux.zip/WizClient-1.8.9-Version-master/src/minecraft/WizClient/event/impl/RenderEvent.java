package WizClient.event.impl;

import WizClient.event.Event;

public class RenderEvent extends Event {

	
	
}
